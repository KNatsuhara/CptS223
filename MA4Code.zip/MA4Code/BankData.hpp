#ifndef BANK_DATA_H
#define BANK_DATA_H

#include <iostream>

class BankData
{
public:
	// Are the Big Five necessary?
	// How will this data work with the std::map?
	//Constructor
	BankData()
	{
		mpAcctNum = nullptr;
		mpSavingsAmount = nullptr;
		mpCheckingAmount = nullptr;
	}

	//Parameterized Constructor
	BankData(const int &newAcctNum, const double &newSavingsAmount, const double &newCheckingAmount)
	{
		this->setAcctNum(newAcctNum);
		this->setSavingsAmount(newSavingsAmount);
		this->setCheckingAmount(newCheckingAmount);
	}

	//Copy Constructor
	BankData(const BankData &copy)
	{
		*this = copy;
	}

	//Copy Assigned Operator
	BankData & operator =(const BankData &copy)
	{
		if(this != &copy)
		{
			this->mpAcctNum = copy.mpAcctNum;
			this->mpCheckingAmount = copy.mpCheckingAmount;
			this->mpSavingsAmount = copy.mpSavingsAmount;
		}
		return *this;
	}

	//Move Constructor
	BankData(BankData &&obj)
	{
		this->mpAcctNum = obj.mpAcctNum;
		this->mpCheckingAmount = obj.mpCheckingAmount;
		this->mpSavingsAmount = obj.mpSavingsAmount;

		obj.mpAcctNum = nullptr;
		obj.mpCheckingAmount = nullptr;
		obj.mpSavingsAmount = nullptr;
	}

	//Move Assignment Operator
	BankData & operator =(BankData &&obj)
	{
		if(this != &obj)
		{
			if(this->mpAcctNum != nullptr)
			{
				this->mpAcctNum = nullptr;
				this->mpCheckingAmount = nullptr;
				this->mpSavingsAmount = nullptr;
			}
			//Get resources from obj
			this->mpAcctNum = obj.mpAcctNum;
			this->mpCheckingAmount = obj.mpCheckingAmount;
			this->mpSavingsAmount = obj.mpSavingsAmount;

			//Reset obj
			obj.mpAcctNum = nullptr;
			obj.mpCheckingAmount = nullptr;
			obj.mpSavingsAmount = nullptr;
		}
		return *this;
	}

	//Destructor
	~BankData()
	{
		//delete this->mpAcctNum;
		//delete this->mpCheckingAmount;
		//delete this->mpSavingsAmount;
		this->mpAcctNum = nullptr;
		this->mpCheckingAmount = nullptr;
		this->mpSavingsAmount = nullptr;
	}

	friend std::ostream& operator << (std::ostream& output, const BankData &data)
	{
		output << data.getAcctNum() << ", " << data.getSavingsAmount() << ", " << data.getCheckingAmount();
		return output;
	}

	int getAcctNum() const; // we do want to return a copy of the int, not the pointer
	double getSavingsAmount() const; // we do want to return a copy of the double, not the pointer
	double getCheckingAmount() const; // we do want to return a copy of the double, not the pointer

	void setAcctNum(const int& newAcctNum); // you need to implement
	void setSavingsAmount(const double& newSavingsAmount); // you need to implement
	void setCheckingAmount(const double& newCheckingAmount); // you need to implement

private:
	int* mpAcctNum;
	double* mpSavingsAmount, * mpCheckingAmount;
};

#endif
