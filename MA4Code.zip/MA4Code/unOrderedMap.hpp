#ifndef UNORDEREDMAP_HPP
#define UNORDEREDMAP_HPP

#include "BankData.hpp"
#include <unordered_map>
#include <iostream>
#include <fstream>
#include <sstream>

void insertData(std::unordered_map<int, BankData> &map)
{
    std::fstream dataFile;
    dataFile.open("BankAccounts.csv");

    if(!dataFile.is_open())
    {
        std::cout << "File did not open!\n" << std::endl;
        return;
    }
    //UserName,"Last,First,Email,NumTweets,MostViewedCategory"
    BankData add;
    std::string line, accNum, checkAmount, savingAmount, delim;
    int acc;
    double check, saving;

    getline(dataFile,delim);

    while(getline(dataFile, line))
    {
        std::stringstream ss(line);
        getline(ss, accNum, ',');
        getline(ss, savingAmount, ',');
        getline(ss, checkAmount);

        acc = std::stoi(accNum);
        saving = std::stod(savingAmount);
        check = std::stod(checkAmount);

        add.setAcctNum(acc);
        add.setCheckingAmount(check);
        add.setSavingsAmount(saving);

        map.insert(std::pair<int, BankData>(acc, add));
    }
    dataFile.close();
}

void printData(std::unordered_map<int, BankData> map)
{
    for(auto it = map.cbegin(); it != map.cend(); ++it)
    {
        std::cout << "[" << it->first << ":" << it->second << "]" << std::endl;
    }
}

void printNumberBucket(std::unordered_map<int, BankData> map)
{
    for (auto& x: map) 
    {
        std::cout << "[" << x.first << ":" << x.second << "]";
        std::cout << " is in bucket #" << map.bucket (x.first) << std::endl;
    }
}

void printDataInBucket(std::unordered_map<int, BankData> map)
{   
    unsigned n = map.bucket_count();

    for (unsigned i=0; i<n; ++i) {
    std::cout << "bucket #" << i << " contains: ";
    for (auto it = map.begin(i); it!=map.end(i); ++it)
      std::cout << "[" << it->first << ":" << it->second << "] ";
    std::cout << "\n";
  }
}

#endif