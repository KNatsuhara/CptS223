/*
1. Assuming that the underlying hash table created cannot be resized, and that the hash function is poor, what is the worst-case Big-O for inserting key-value pairs 
based on a key? List any other assumptions that you make.
	- The worst-case Big-O notation for inserting a key-value pair if the hash table cannot be resized is O(n) if the hash table is not completely full. If the hash table
is completely full then either the inserting algorithm will run infinitely or will stop when it has checked all the buckets in the hash table.

2. Let’s say that the underlying hash table uses linear probing, what is the worst-case Big-O for retrieving data based on a key? List any assumptions that you make.
	- If the hash table uses linear probing, the worst-case Big-O notation for retrieving data based on a key is O(n).

3. Let’s say the underlying hash table uses chaining, what is the worst-case Big-O for deleting key-value pairs based on a key? List any assumptions that you make.
	- If the hash table uses chaining, the worst-case Big-O for deleting key-value pairs based on a key is O(n).

4. What is the worst-case Big-O for iterating through the entire unordered map? List any assumptions that you make.
	- The worst-case Big-O for iterating through the entrie unorder map would be O(n) because you will have to go through each element.

5. Based on your conclusions of the tasks that were performed in this assignment, when and why should we use an unordered map?
	- You would use an unordered map if all your key-value pairs are unique and have their own separate bucket so that the search, insert, and deletion time complexities
	are constant O(1).

6. Is an std::unordered_map a robust choice for storing, removing, and searching bank accounts? Explain.
	- An unordered_map is a robust choice for storing, removing, and searching bank accounts because the unordered map functions as a hash table which will have on average
	constant time complexity for storing, removing and searching. This will require a large amount of space and a good hashing function for the key-value pairs.
	If the bank account ID all have unique IDs then you won't need to worry about duplicate key-value pairs which will negate collisions


*/

#include "unOrderedMap.hpp"
#include "BankData.hpp"

int main(int argc, char* argv[])
{
	// we need a unordered map to store our key and mapped values
	// std::unordered_map<keyType, ValueType>; What should the key be? What about the value?

	std::unordered_map<int, BankData> map;


	std::cout << "---------- Inserting and bucket number of each data ----------\n";
	insertData(map);
	printNumberBucket(map);

	std::cout << "---------- Number of buckets in each container ----------\n";
	printDataInBucket(map);

	std::cout << "---------- Max number of elements that can be stored ----------\n";
	std::cout << "Max number of elements stored in a container: " << map.max_size() << std::endl;

	std::cout << "---------- Map before deletions----------\n";
	printData(map);

	map.erase(11111111);
	std::cout << "---------- Map after deletion of 11111111 ----------\n";
	printData(map);





	
	return 0;
}