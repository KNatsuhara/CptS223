#pragma once

#ifndef REDBLACKTREE_HPP
#define REDBLACKTREE_HPP

#include "RedBlackNode.hpp"
#include <vector>
#include <algorithm>
#include <stack>

template <class T>
class RedBlackTree
{
private:
    RedBlackNode<T> *root;
    int size = 0;
protected:
    void makeEmptyHelper(RedBlackNode<T> *t)
    {
        if(t != nullptr)
        {
            makeEmptyHelper(t->left);
            makeEmptyHelper(t->right);
            delete t;
        }
    }

    void printInOrderHelper(RedBlackNode<T> *root)
    {
        if(!root) return;
        printInOrderHelper(root->left);
        std::cout << "<" << root->data << ">" << std::endl;
        printInOrderHelper(root->right);
    }

    void printReverseOrderHelper(RedBlackNode<T> *root)
    {
        if(!root) return;
        printReverseOrderHelper(root->right);
        std::cout << "<" << root->data << ">" << std::endl;
        printReverseOrderHelper(root->left);
    }

    void checkIfNodeUnique(RedBlackNode<T> *root, std::vector<T> &arr)
    {
        if(!root) return;
        checkIfNodeUnique(root->left, arr);
        arr.push_back(root->data);
        checkIfNodeUnique(root->right, arr);
    }

public:
    RedBlackTree();
    RedBlackTree(RedBlackNode<T> root, int size);
    ~RedBlackTree();
    int isEmpty();
    int height(RedBlackNode<T> *t);
    RedBlackNode<T>* insert(RedBlackNode<T> *&root, RedBlackNode<T> *&t);
    void insertBalance(const T &data);
    void balance(RedBlackNode<T> *&root, RedBlackNode<T> *&t);
    void rotateLeft(RedBlackNode<T> *&root, RedBlackNode<T> *&pt);
    void rotateRight(RedBlackNode<T> *&root, RedBlackNode<T> *&pt);
    void remove(const T&data, RedBlackNode<T> *& t);
    void clear();
    void fillTree(std::vector<T> arr);
    void printInOrder();
    void printInReverseOrder();
    void addNewNode(const T &data);
    void removeNode(const T &data);
    void updateNode(const T &data);
    void update(const T &data, RedBlackNode<T> *&t);
    RedBlackNode<T>* findMin(RedBlackNode<T> *root);
};

template <class T>
RedBlackTree<T>::RedBlackTree()
{
    root = nullptr;
    size = 0;
}

template <class T>
RedBlackTree<T>::RedBlackTree(RedBlackNode<T> root, int size)
{
    this->root = root;
}

template <class T>
RedBlackTree<T>::~RedBlackTree()
{
    clear();
}

template <class T>
int RedBlackTree<T>::isEmpty() //returns 1 if it is empty; 0 otherwise
{
    if(this->root == nullptr)
    {
        return 1;
    }
    else
    {
        return 0;
    }
    
}

template <class T>
int RedBlackTree<T>::height(RedBlackNode<T> *t) //returns height of the node or -1 if a nullptr
{
    if(t == nullptr)
    {
        return -1;
    }
    else
    {
        return t->height;
    }
}

template <class T>
RedBlackNode<T>* RedBlackTree<T>::insert(RedBlackNode<T> *& root, RedBlackNode<T> *& t) //inserts data into the tree - must abide by AVL properties
{
    if(root == nullptr)
    {
        return t;
    }
    else if(t->data <= root->data)
    {
        root->left = insert(root->left, t);
        root->left->parent = root;
    }
    else if(root->data <= t->data)
    {
        root->right = insert(root->right, t);
        root->right->parent = root;
    }
    
    return root;
}

template <class T>
void RedBlackTree<T>::insertBalance(const T &data)
{
    RedBlackNode<T> *t = new RedBlackNode<T> {data, nullptr, nullptr, nullptr, RED};
    root = insert(root, t);
    balance(root, t);
}

template <class T>
void RedBlackTree<T>::balance(RedBlackNode<T> *& root, RedBlackNode<T> *& pt) //balances out Red Black Tree
{
    RedBlackNode<T> *parent_pt = NULL; 
    RedBlackNode<T> *grand_parent_pt = NULL; 
  
    while ((pt != root) && (pt->color != BLACK) && (pt->parent->color == RED)) 
    { 
        parent_pt = pt->parent; 
        grand_parent_pt = pt->parent->parent; 
  
        /*  Case : A 
            Parent of pt is left child  
            of Grand-parent of pt */
        if (parent_pt == grand_parent_pt->left) 
        { 
  
            RedBlackNode<T> *uncle_pt = grand_parent_pt->right; 
  
            /* Case : 1 
               The uncle of pt is also red 
               Only Recoloring required */
            if (uncle_pt != NULL && uncle_pt->color == RED) 
            { 
                grand_parent_pt->color = RED; 
                parent_pt->color = BLACK; 
                uncle_pt->color = BLACK; 
                pt = grand_parent_pt; 
            } 
  
            else
            { 
                /* Case : 2 
                   pt is right child of its parent 
                   Left-rotation required */
                if (pt == parent_pt->right) 
                { 
                    rotateLeft(root, parent_pt); 
                    pt = parent_pt; 
                    parent_pt = pt->parent; 
                } 
  
                /* Case : 3 
                   pt is left child of its parent 
                   Right-rotation required */
                rotateRight(root, grand_parent_pt); 
                std::swap(parent_pt->color, grand_parent_pt->color); 
                pt = parent_pt; 
            } 
        } 
  
        /* Case : B 
           Parent of pt is right child  
           of Grand-parent of pt */
        else
        { 
            RedBlackNode<T> *uncle_pt = grand_parent_pt->left; 
  
            /*  Case : 1 
                The uncle of pt is also red 
                Only Recoloring required */
            if ((uncle_pt != NULL) && (uncle_pt->color ==  
                                                    RED)) 
            { 
                grand_parent_pt->color = RED; 
                parent_pt->color = BLACK; 
                uncle_pt->color = BLACK; 
                pt = grand_parent_pt; 
            } 
            else
            { 
                /* Case : 2 
                   pt is left child of its parent 
                   Right-rotation required */
                if (pt == parent_pt->left) 
                { 
                    rotateRight(root, parent_pt); 
                    pt = parent_pt; 
                    parent_pt = pt->parent; 
                } 
  
                /* Case : 3 
                   pt is right child of its parent 
                   Left-rotation required */
                rotateLeft(root, grand_parent_pt); 
                std::swap(parent_pt->color, grand_parent_pt->color); 
                pt = parent_pt; 
            } 
        } 
    } 
  
    root->color = BLACK; 
}

template <class T>
void RedBlackTree<T>::rotateLeft(RedBlackNode<T> *&root, RedBlackNode<T> *&pt)
{
     RedBlackNode<T> *pt_right = pt->right; 
  
    pt->right = pt_right->left; 
  
    if (pt->right != NULL) 
        pt->right->parent = pt; 
  
    pt_right->parent = pt->parent; 
  
    if (pt->parent == NULL) 
        root = pt_right; 
  
    else if (pt == pt->parent->left) 
        pt->parent->left = pt_right; 
  
    else
        pt->parent->right = pt_right; 
  
    pt_right->left = pt; 
    pt->parent = pt_right; 
}

template <class T>
void RedBlackTree<T>::rotateRight(RedBlackNode<T> *&root, RedBlackNode<T> *&pt)
{
    RedBlackNode<T> *pt_left = pt->left; 
  
    pt->left = pt_left->right; 
  
    if (pt->left != NULL) 
        pt->left->parent = pt; 
  
    pt_left->parent = pt->parent; 
  
    if (pt->parent == NULL) 
        root = pt_left; 
  
    else if (pt == pt->parent->left) 
        pt->parent->left = pt_left; 
  
    else
        pt->parent->right = pt_left; 
  
    pt_left->right = pt; 
    pt->parent = pt_left; 
}

template <class T>
void RedBlackTree<T>::remove(const T &data, RedBlackNode<T> *& t) //removes item from tree - must abide by AVL properties
{
    if(t==nullptr)
    {
        return;
    }

    if(data < t->data)
    {
        remove(data, t->left);
    }
    else if(t->data < data)
    {
        remove(data, t->right);
    }
    else if(t->left != nullptr && t->right != nullptr) //two children
    {
        t->data = findMin(t->right)->data;
        remove (t->data, t->right);
    }
    else
    {
        RedBlackNode<T> *oldNode = t;
        t = (t->left != nullptr) ? t->left : t->right;
        delete oldNode;
    }
}

template <class T>
void RedBlackTree<T>::clear() //removes all nodes from tree
{
    if(this->root)
    {
        this->makeEmptyHelper(this->root);
    }
    this->root = nullptr;
}

template <class T>
void RedBlackTree<T>::fillTree(std::vector<T> arr) //fills entire tree with data from T array
{
    for(int i = 0; i < arr.size(); i++)
    {
        insertBalance(arr.at(i));
    }
}

template <class T>
void RedBlackTree<T>::printInOrder() //prints the data in the nodes in increasing order
{
    printInOrderHelper(this->root);
}

template <class T>
void RedBlackTree<T>::printInReverseOrder() //prints the data of the nodes in decreasing order
{
    printReverseOrderHelper(this->root);
}

template <class T>
void RedBlackTree<T>::addNewNode(const T &data)
{
    std::vector<T> arr;

    checkIfNodeUnique(this->root, arr);

    for(int i = 0; i < arr.size(); i++)
    {
        if(arr.at(i) == data)
        {
            std::cout << "CANNOT INSERT! There is an item that shares the same ID!" << std::endl;
            return;
        }
    }
    insertBalance(data);
    std::cout << "Successfully inputted: <" << data << ">\n";
}

template <class T>
void RedBlackTree<T>::removeNode(const T &data)
{
    std::vector<T> arr;

    checkIfNodeUnique(this->root, arr);

    for(int i = 0; i < arr.size(); i++)
    {
        if(arr.at(i) == data)
        {
            remove(data, root);
            std::cout << "Succesfully deleted!\n"; 
            return;
        }
    }

    std::cout << "CANNOT REMOVE! There is no item found with that ID." << std::endl;
}

template <class T>
void RedBlackTree<T>::updateNode(const T &data)
{
    std::vector<T> arr;
    checkIfNodeUnique(this->root, arr);

    for(int i = 0; i < arr.size(); i++)
    {
        if(arr.at(i) == data)
        {
            update(data, root);
            std::cout << "Succesfully updated!\n"; 
            return;
        }
    }

    std::cout << "CANNOT Update! There is no item found with that ID." << std::endl;
}

template <class T>
void RedBlackTree<T>::update(const T &data, RedBlackNode<T> *&t)
{
    if(t==nullptr)
    {
        return;
    }

    if(data < t->data)
    {
        update(data, t->left);
    }
    else if(t->data < data)
    {
        update(data, t->right);
    }
    else
    {
        t->data = data;
    }
}

template <class T>
RedBlackNode<T>* RedBlackTree<T>::findMin(RedBlackNode<T> *root)
{
    while(root->left != nullptr)
        root = root->left;
    return root;
}



#endif