#pragma once

#ifndef INVENTORYRECORD_HPP
#define INVENTORYRECORD_HPP

#include <iostream>
#include <string>

class InventoryRecord
{
private:
    int ID;
    std::string type;
    int numItems;
public:
    InventoryRecord(); //Constructor
    InventoryRecord(int ID, std::string type, int num); //Parameterized Constructor
    ~InventoryRecord(); //Destructor
    InventoryRecord(const InventoryRecord &copy); //Copy Constructor
    InventoryRecord& operator= (const InventoryRecord &copy); //Copy Assignment Operator
    InventoryRecord(InventoryRecord&& obj); //Move constructor
    InventoryRecord& operator=(InventoryRecord &&obj); //Move Assignment Operator

    friend std::ostream& operator << (std::ostream& output, const InventoryRecord &data)
    {
        output << data.getID() << "," << data.getType() << "," << data.getNumItems();
        return output;
    }
    
    bool operator== (const InventoryRecord &A) const;
    bool operator<= (const InventoryRecord &A) const;
    bool operator< (const InventoryRecord &A) const;

    int getID() const;
    std::string getType() const;
    int getNumItems() const;

    void setID(int ID);
    void setType(std::string type);
    void setNumItems(int num);
};


#endif