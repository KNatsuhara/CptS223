#pragma once

#ifndef HEADER_HPP
#define HEADER_HPP

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <vector>

#include "InventoryRecord.hpp"

//Returns vector full of data from csv file
void getFileData(std::vector<InventoryRecord> &arr);
InventoryRecord newRecord();
InventoryRecord newDeleteRecord();
void printMenu();
int getOption();
void pauseClear();

#endif