#pragma once

#ifndef REDBLACKNODE_HPP
#define REDBLACKNODE_HPP

#include <iostream>
#include <string>

enum Color{RED, BLACK};

template <class T>
class RedBlackTree;

template <class T>
class RedBlackNode
{
    friend class RedBlackTree<T>;
private:
    T data;
    RedBlackNode<T> *left;
    RedBlackNode<T> *right;
    RedBlackNode<T> *parent;
    bool color;
    int height;
public:
    RedBlackNode(T data);
    RedBlackNode(const T &data, RedBlackNode<T> *left, RedBlackNode<T> *right, RedBlackNode<T> *parent, bool color);
    RedBlackNode(T &&data, RedBlackNode<T> *left, RedBlackNode<T> *right, RedBlackNode<T> *parent, bool color);
    ~RedBlackNode();
    //others?
    RedBlackNode<T> *getLeft() {return left;}
    RedBlackNode<T> *getRight() {return right;}
    RedBlackNode<T> *getParent() {return parent;}
    T getData() {return data;}
};

//constructor
template <class T>
RedBlackNode<T>::RedBlackNode(T data)
{
    this->data = data;
    this->left = nullptr;
    this->right = nullptr;
    this->parent = nullptr;
    this->color = RED;
}


//Copy Constructor
template <class T>
RedBlackNode<T>::RedBlackNode(const T &data, RedBlackNode<T>* left, RedBlackNode<T>* right, RedBlackNode<T> *parent, bool color)
{
    this->data = data;
    this->left = left;
    this->right = right;
    this->parent = parent;
    this->color = color;
    this->height = 0;

}

//Move constructor
template <class T>
RedBlackNode<T>::RedBlackNode(T &&data, RedBlackNode<T> *left, RedBlackNode<T>* right, RedBlackNode<T> *parent, bool color)
{
    this->data = std::move(data);
    this->left = left;
    this->right = right;
    this->parent = parent;
    this->color = color;
    this->height = 0;
}

//Deconstructor
template <class T>
RedBlackNode<T>::~RedBlackNode()
{
    this->height = 0;
    this->left = nullptr;
    this->right = nullptr;
    this->parent = nullptr;
    this->color = false;
}

#endif