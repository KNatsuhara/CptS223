#include "header.hpp"

void getFileData(std::vector<InventoryRecord> &arr)
{
    int i = 0;
    std::string type, strComb, strNumItems;
    int comb = 0, numItems = 0;
    std::string line;

    std::fstream datafile;
    datafile.open("Inventory.csv");
    InventoryRecord add;

    //check if infile is open
    if(!datafile.is_open())
    {
        std::cout << "CSV file is not open!" << std::endl;
        return;
    }

    while(std::getline(datafile, line))
    {
        std::stringstream ss(line);
        getline(ss, strComb, ',');
        getline(ss, type, ',');
        getline(ss, strNumItems);
        comb = std::stoi(strComb);
        numItems = std::stoi(strNumItems);
        add.setID(comb);
        add.setType(type);
        add.setNumItems(numItems);
        arr.push_back(add);
    }
    datafile.close();
}

InventoryRecord newRecord()
{
    int ID, numItems;
    std::string type;

    std::cout << "Input a 4-digit ID: ";
    std::cin >> ID;
    std::cin.ignore();

    std::cout << "Input the type of the item: ";
    std::getline(std::cin, type);

    std::cout << "Input the number of items: ";
    std::cin >> numItems;

    InventoryRecord newRecord(ID, type, numItems);

    return newRecord;
}

InventoryRecord newDeleteRecord()
{
    int ID, numItems = 0;
    std::string type = "N/A";

    std::cout << "What is the ID of the object you want to delete?: ";
    std::cin >> ID;

    InventoryRecord deleteRecord(ID, type, numItems);

    return deleteRecord;
} 

void printMenu()
{
    std::cout << "========== Main Menu ==========\n";
    std::cout << "1. Add new item to inventory\n";
    std::cout << "2. Remove item from inventory\n";
    std::cout << "3. Update item in inventory\n";
    std::cout << "4. Display item in inventory\n";
    std::cout << "5. Exit\n";
}

int getOption()
{
    int option = 0;
    do
    {
        printMenu();
        std::cout << "What option would you like to select?: ";
        std::cin >> option;
    } while (option < 1 || option > 5);

    return option;
}

void pauseClear()
{
    std::cout << "Press Enter to continue...";
    std::cin.ignore();
    std::cin.get();
    std::system("clear");
}