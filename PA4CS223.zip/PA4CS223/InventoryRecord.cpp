#include "InventoryRecord.hpp"

InventoryRecord::InventoryRecord() //Constructor
{
    this->ID = 0;
    this->type = "";
    this->numItems = 0;
}

InventoryRecord::InventoryRecord(int ID, std::string type, int num) //Parameterized Constructor
{
    this->ID = ID;
    this->type = type;
    this->numItems = num;
}

InventoryRecord::~InventoryRecord() //Destructor
{
    this->ID = 0;
    this->type = "";
    this->numItems = 0;
}

InventoryRecord::InventoryRecord(const InventoryRecord &copy) //Copy Constructor
{
    *this = copy;
}

InventoryRecord& InventoryRecord::operator=(const InventoryRecord &copy) //Copy Assignment Operator
{
    if(this != &copy)
    {
        this->ID = copy.ID;
        this->type = copy.type;
        this->numItems = copy.numItems;
    }

    return *this;
}

InventoryRecord::InventoryRecord(InventoryRecord&& obj) //Move constructor
{
    this->ID = obj.ID;
    this->type = obj.type;
    this->numItems = obj.numItems;

    obj.ID = 0;
    obj.type = "";
    obj.numItems = 0;
}

InventoryRecord& InventoryRecord::operator=(InventoryRecord &&obj) //Move Assignment Operator
{
    if(this != &obj)
    {
        if(this->ID != 0)
        {
            this->ID = 0;
            this->type = "";
            this->numItems = 0; 
        }

        this->ID = obj.ID;
        this->type = obj.type;
        this->numItems = obj.numItems;

        obj.ID = 0;
        obj.type = "";
        obj.numItems = 0;
    }

    return *this;
}

bool InventoryRecord::operator== (const InventoryRecord &A) const
{
    if(ID == A.ID)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool InventoryRecord::operator<= (const InventoryRecord &A) const
{
    if(ID <= A.ID)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool InventoryRecord::operator< (const InventoryRecord &A) const
{
    if(ID < A.ID)
    {
        return true;
    }
    else
    {
        return false;
    }
}

int InventoryRecord::getID() const
{
    return this->ID;
}

std::string InventoryRecord::getType() const
{
    return this->type;
}

int InventoryRecord::getNumItems() const
{
    return this->numItems;
}

void InventoryRecord::setID(int ID)
{
    this->ID = ID;
}

void InventoryRecord::setType(std::string type)
{
    this->type = type;
}

void InventoryRecord::setNumItems(int num)
{
    this->numItems = num;
}