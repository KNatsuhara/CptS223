#include "header.hpp"
#include "InventoryRecord.hpp"
#include "RedBlackTree.hpp"

/*
    What is the worst-case Big-O of the insert() algorithm for the red-black tree? Explain.
    The worst-case Big-O of the insert() algorithm for the red-black tree is O(logn) because traversing the tree
    is O(logn) and every other function has a time complexity of O(1).

    What is the worst-case Big-O of the remove() algorithm for the red-black tree? Explain.
    The worst-case Big-O of the remove() algorithm for the red-black tree is O(logn) because traversing the tree
    is O(logn) and every other function has a time complexity of O(1).

    What is the worst-case Big-O of the clear() algorithm for the red-black tree? Explain.
    The worst-case Big-O of the clear() algorithm for the red-black tree is O(n) because this function requires
    the traversal of the entire tree and therefore deleting all the nodes within the tree.
*/

int main(int argc, char *argv[])
{
    InventoryRecord test;
    RedBlackTree<InventoryRecord> please;
    std::vector<InventoryRecord> arr;
    getFileData(arr);
    please.fillTree(arr);
    bool loop = true;
    int option = 0;

    while(loop)
    {
        option = getOption();
        switch(option)
        {
            case 1:
                std::cout << "========== Inserting Inventory Record ==========\n";
                test = newRecord();
                please.addNewNode(test);
                pauseClear();
                break;
            case 2:
                std::cout << "========== Removing Inventory Record ==========\n";
                test = newDeleteRecord();
                please.removeNode(test);
                pauseClear();
                break;
            case 3:
                std::cout << "========== Update Existing Inventory Record ==========\n";
                test = newRecord();
                please.updateNode(test);
                pauseClear();
                break;
            case 4:
                std::cout << "========== Displaying all Inventory Records ==========\n";
                please.printInOrder();
                pauseClear();
                break;
            case 5:
                std::cout << "========== Exiting ==========\n";
                loop = false;
                break;
        }
    }

    return 0;
}