#include "Heap.h"

int main()
{
    srand(time(NULL));

    Heap<int> test;

    for(int i = 0; i < 1000; i++)
    {
        test.push(rand() % 1000000 + 1);
    }

    test.print_array();

    std::cout << "========================================\n";

    std::cout << "5th smallest element in heap: " << test.find_k_smallest_item(5) << std::endl;

    return 0;
}