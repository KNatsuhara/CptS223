#pragma once

#ifndef AVLTREE_HPP
#define AVLTREE_HPP

#include "AVLNode.hpp"

#include <iostream>
#include <algorithm>

static const int ALLOWED_IMBALANCE = 1;

template <class T>
class AVLTree
{
private:
    AVLNode<T> *root;
    std::string label;
    int size = 0;
    int count = 1;
protected:
    void makeEmptyHelper(AVLNode<T> *t)
    {
        if(t != nullptr)
        {
            makeEmptyHelper(t->left);
            makeEmptyHelper(t->right);
            delete t;
        }
    }
    void printInOrderHelper(AVLNode<T> *root)
    {
        if(!root) return;
        printInOrderHelper(root->left);
        std::cout << "<" << label << ":" << count << "." << root->data << std::endl;;
        count++;
        printInOrderHelper(root->right);
    }

    void printReverseOrderHelper(AVLNode<T> *root)
    {
        if(!root) return;
        printReverseOrderHelper(root->right);
        std::cout << "<" << label << ":" << count << "." << root->data << std::endl;
        count++;
        printReverseOrderHelper(root->left);
    }

    T getMaxHelper(AVLNode<T> *root)
    {
        while(root->right != nullptr)
        {
            root = root->right;
        }
        std::cout << "<" << label << ":1." << root->data << std::endl;
        return root->data;
    }

    T getMinHelper(AVLNode<T> *root)
    {
        while(root->left != nullptr)
        {
            root = root->left;
        }
        std::cout << "<" << label << ":50." << root->data << std::endl;
        return root->data;
    }

public:
    AVLTree();
    AVLTree(AVLNode<T> root, int size);
    ~AVLTree();
    int isEmpty(); //returns 1 if it is empty; 0 otherwise
    int height(AVLNode<T> *t); //returns hieght of the node or -1 if a nullptr
    void insert(const T &data, AVLNode<T> *& t); //inserts data into the tree - must abide by AVL properties
    void balance(AVLNode<T> *&t); //balances out AVL Tree
    void rotateWithLeftChild(AVLNode<T> *& k2);
    void doubleWithLeftChild(AVLNode<T>* & k3);
    void rotateWithRightChild(AVLNode<T> *& k2);
    void doubleWithRightChild(AVLNode<T>* & k3);
    void remove(const T &data, AVLNode<T> *& t); //removes item from tree - must abide by AVL properties
    void clear(); //removes all nodes from tree
    void fillTree(T data[], int size); //fills entire tree with data from T array
    T findMin(); //returns the smallest item in the tree
    T findMax(); //returns the largest item in the tree
    void printInOrder(); //prints the data of the nodes in increasing order
    void printReverseOrder(); //prints the data of the nodes in decreasing order
    void setLabel(std::string label); //sets label of the tree
    void resetCount() {count = 1;} //Resets count back to 1
};

template <class T>
AVLTree<T>::AVLTree()
{
    root = nullptr;
    size = 0;
}

template <class T>
AVLTree<T>::AVLTree(AVLNode<T> root, int size)
{
    this->root = root;
}

template <class T>
AVLTree<T>::~AVLTree()
{
    clear();
}

template <class T>
int AVLTree<T>::isEmpty() //returns 1 if it is empty; 0 otherwise
{
    if(this->root == nullptr)
    {
        return 1;
    }
    else
    {
        return 0;
    }
    
}

template <class T>
int AVLTree<T>::height(AVLNode<T> *t) //returns height of the node or -1 if a nullptr
{
    if(t == nullptr)
    {
        return -1;
    }
    else
    {
        return t->height;
    }
}

template <class T>
void AVLTree<T>::insert(const T &data, AVLNode<T> *& t) //inserts data into the tree - must abide by AVL properties
{
    if(t == nullptr)
    {
        t = new AVLNode<T> {data, nullptr, nullptr};
    }
    else if(data <= t->data)
    {
        insert(data, t->left);
    }
    else if(t->data <= data)
    {
        insert(data, t->right);
    }
    balance(t);
}

template <class T>
void AVLTree<T>::balance(AVLNode<T> *&t) //balances out AVL Tree
{
    if(t == nullptr)
    {
        return;
    }
    if(height (t->left) - height(t->right) > ALLOWED_IMBALANCE)
    {
        if(height(t->left->left) >= height(t->left->right))
        {
            rotateWithLeftChild(t);
        }
        else
        {
            doubleWithLeftChild(t);
        }
    }
    else
    {
        if(height(t->right) - height(t->left) > ALLOWED_IMBALANCE)
        {
            if(height(t->right->right) >= height(t->right->left))
            {
                rotateWithRightChild(t);
            }
            else
            {
                doubleWithRightChild(t);
            }
        }
    }
    t->height = std::max(height(t->left), height(t->right)) + 1;
}

template <class T>
void AVLTree<T>::rotateWithLeftChild(AVLNode<T> *& k2)
{
    AVLNode<T> *k1 = k2->left;
    k2->left = k1->right;
    k1->right = k2;
    k2->height = std::max(height(k2->left), height(k2->right)) + 1;
    k1->height = std::max(height(k1->left), k2->height) + 1;
    k2 = k1;
}

template <class T>
void AVLTree<T>::doubleWithLeftChild(AVLNode<T>* & k3)
{
    rotateWithRightChild(k3->left);
    rotateWithLeftChild(k3);
}

template <class T>
void AVLTree<T>::rotateWithRightChild(AVLNode<T> *& k2)
{
    AVLNode<T> *k1 = k2->right;
    k2->right = k1->left;
    k1->left = k2;
    k2->height = std::max(height(k1->left), height(k1->right)) + 1;
    k1->height = std::max(height(k1->right), k2->height) + 1;
    k2 = k1;
}

template <class T>
void AVLTree<T>::doubleWithRightChild(AVLNode<T>* & k3)
{
    rotateWithLeftChild(k3->right);
    rotateWithRightChild(k3);
}

template <class T>
void AVLTree<T>::remove(const T &data, AVLNode<T> *& t) //removes item from tree - must abide by AVL properties
{
    if(t==nullptr)
    {
        return;
    }

    if(data <= t->data)
    {
        remove(data, t->left);
    }
    else if(t->data <= data)
    {
        remove(data, t->right);
    }
    else if(t->left != nullptr && t->right != nullptr) //two children
    {
        t->data = std::min(t->right)->data;
        remove (t->data, t->right);
    }
    else
    {
        AVLNode<T> *oldNode = t;
        t = (t->left != nullptr) ? t->left : t->right;
        delete oldNode;
    }
    
    balance(t);
}

template <class T>
void AVLTree<T>::clear() //removes all nodes from tree
{
    if(this->root)
    {
        this->makeEmptyHelper(this->root);
    }
    this->root = nullptr;
}

template <class T>
void AVLTree<T>::fillTree(T data[], int size) //fills entire tree with data from T array
{
    for(int i = 0; i < size; i++)
    {
        insert(data[i], root);
    }
}

template <class T>
T AVLTree<T>::findMin() //returns the smallest item in the tree
{
    return getMinHelper(this->root);
}

template <class T>
T AVLTree<T>::findMax() //returns the largest item in the tree
{
    return getMaxHelper(this->root);
}

template <class T>
void AVLTree<T>::printInOrder() //prints the data in the nodes in increasing order
{
    printInOrderHelper(this->root);
    resetCount();
}

template <class T>
void AVLTree<T>::printReverseOrder() //prints the data of the nodes in decreasing order
{
    printReverseOrderHelper(this->root);
    resetCount();
}

template<class T>
void AVLTree<T>::setLabel(std::string label) //sets label of the tree
{
    this->label = label;
}
#endif