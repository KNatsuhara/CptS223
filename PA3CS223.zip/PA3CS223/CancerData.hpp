#pragma once

#ifndef CANCERDATA_HPP
#define CANCERDATA_HPP

#include <iostream>

class CancerData
{
private:
    std::string countryName;
    double cancerRate;
public:
    CancerData();
    CancerData(std::string name, double rate);
    ~CancerData();
    bool operator<=(const CancerData &A) const;
    friend std::ostream& operator<<(std::ostream& output, const CancerData& A)
    {
        output << A.countryName << "." << A.cancerRate << ".>";
        return output;
    }
    //others?
    std::string getName() {return countryName;}
    double getRate() {return cancerRate;}
    void setName(std::string s) {countryName = s;}
    void setRate(double r) {cancerRate = r;}
    void printCancerData();
};

#endif