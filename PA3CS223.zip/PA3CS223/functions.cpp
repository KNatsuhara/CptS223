#include "header.hpp"

//Returns vector full of data from csv file
void getFileData(std::fstream& infile, CancerData arr[], int size)
{
    int i = 0;
    std::string country, r;
    double rate = 0.0;
    std::string line;

    //check if infile is open
    if(!infile.is_open())
    {
        std::cout << "CSV file is not open!" << std::endl;
        return;
    }

    for(int i = 0; i < size; i++)
    {
        getline(infile,line);
        std::stringstream ss(line);
        getline(ss, country, ',');
        getline(ss, r);
        rate = std::stod(r);
        arr[i].setName(country);
        arr[i].setRate(rate);
    }
    infile.close();
}