#include "CancerData.hpp"

//Constructor
CancerData::CancerData()
{
    countryName = "";
    cancerRate = 0;
}

//Copy Constructer
CancerData::CancerData(std::string name, double rate)
{
    this->countryName = name;
    this->cancerRate = rate;
}

//Deconstructer
CancerData::~CancerData()
{
    this->countryName = "";
    this->cancerRate = 0.0;
}

//Compare Overload Operator <=
bool CancerData::operator<=(const CancerData &A) const
{
    if(cancerRate <= A.cancerRate)
    {
        return true;
    }
    else
    {
        return false;
    }
}
   
void CancerData::printCancerData()
{
    std::cout << countryName << ", " << cancerRate << std::endl;
}