#pragma once

#ifndef AVLNODE_HPP
#define AVLNODE_HPP

#include <iostream>

template <class T>
class AVLTree;

template <class T>
class AVLNode
{
    friend class AVLTree<T>;
private:
    T data;
    AVLNode<T> *left;
    AVLNode<T> *right;
    int height;
public:
    AVLNode(const T &data, AVLNode<T>* left, AVLNode<T>* right);
    AVLNode(T &&data, AVLNode<T> *left, AVLNode<T>* right);
    ~AVLNode();
    //others?
    AVLNode<T>* getLeft() {return left;}
    AVLNode<T>* getRight() {return right;} 
    T getData() {return data;}
};

//Copy Constructor
template <class T>
AVLNode<T>::AVLNode(const T &data, AVLNode<T>* left, AVLNode<T>* right)
{
    this->data = data;
    this->height = 0;
    this->left = left;
    this->right = right;
}

//Move constructor
template <class T>
AVLNode<T>::AVLNode(T &&data, AVLNode<T> *left, AVLNode<T>* right)
{
    this->data = std::move(data);
    this->height = 0;
    this->left = left;
    this->right = right;
}

//Deconstructor
template <class T>
AVLNode<T>::~AVLNode()
{
    //erase data
    this->height = 0;
    this->left = nullptr;
    this->right = nullptr;
}

#endif