/*
What is the worst-case Big-O of the insert () algorithm for the AVL tree? Explain.
The worst-case Big-O of the insert() algorithm for the AVL tree is O(logN). The tree AVL tree
is self-balancing and the number of traversals to reach each node and insert a node will always
have the worst-case of O(logn).

What is the worst-case Big-O of the printInOrder () algorithm for the AVL tree? Explain.
The worst-case Big-O of the printInorder function is O(logN) because the AVL tree is self-balancing
number of traversals to reach all nodes within the tree is reduced to O(logN). 

What is the worst-case Big-O of the findMax () algorithm for the AVL tree? Explain.
The worst case Big-O of the findMax() function is O(logN) because the AVL tree is constantly balancing
all the nodes so that the difference in levels of each sub tree is no more than 1, therefore the worst-case
scenario is O(logN).


SOME OF THIS CODE IS REFERENCED FROM Fourth Edition Data Structures and Algorithm Analysis in C++ by Mark Allen Weiss
specifically the AVLTree balance and rotate functions.
*/

#include "header.hpp"
#include "CancerData.hpp"
#include "AVLTree.hpp"


int main(int argc, char *argv[])
{
    std::fstream bothFile;
    bothFile.open("bothcancerdata.csv");
    std::fstream menFile;
    menFile.open("mencancerdata.csv");
    std::fstream womenFile;
    womenFile.open("womencancerdata.csv");

    CancerData a_both[50], a_men[50], a_women[50];

    getFileData(bothFile, a_both, 50);
    getFileData(menFile, a_men, 50);
    getFileData(womenFile, a_women, 50);

    AVLTree<CancerData> both, men, women;

    both.fillTree(a_both, 50);
    both.setLabel("Both");

    men.fillTree(a_men,50);
    men.setLabel("Men");

    women.fillTree(a_women, 50);
    women.setLabel("Women");

    std::cout << "================ Global Cancer Rates BOTH ================\n";
    both.printReverseOrder();
    std::cout << "================ Global Cancer Rates MEN ================\n";
    men.printReverseOrder();
    std::cout << "================ Global Cancer Rates WOMEN ================\n";
    women.printReverseOrder();


    std::cout << "================ 1st Ranked Cancer Rates ================\n";
    CancerData maxB = both.findMax();
    CancerData maxM = men.findMax();
    CancerData maxW = women.findMax();

    std::cout << "================ 50th Ranked Cancer Rates ================\n";
    CancerData minB = both.findMin();
    CancerData minM = men.findMin();
    CancerData minW = women.findMin();

    std::cout << "Finished Outputting Results\n";

    return 0;
}