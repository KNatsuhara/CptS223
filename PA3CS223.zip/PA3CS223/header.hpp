#pragma once

#ifndef HEADER_HPP
#define HEADER_HPP

#include "CancerData.hpp"

#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>

//Returns vector full of data from csv file
void getFileData(std::fstream& infile, CancerData arr[], int size);

#endif