#ifndef MAP_HPP
#define MAP_HPP

#include "TwitterData.hpp"

#include <map>
#include <iostream>
#include <fstream>
#include <sstream>

void insertData(std::map<std::string, TwitterData> &map)
{
    std::fstream dataFile;
    dataFile.open("TwitterAccounts.csv");

    if(!dataFile.is_open())
    {
        std::cout << "File did not open!\n" << std::endl;
        return;
    }
    //UserName,"Last,First,Email,NumTweets,MostViewedCategory"
    TwitterData add;
    std::string line, user, name, email, category, last, first, tweets, delim;
    int numTweets;

    getline(dataFile,delim);

    while(getline(dataFile, line))
    {
        std::stringstream ss(line);
        getline(ss, user, ',');
        getline(ss, delim, '"');
        getline(ss, last, ',');
        getline(ss, first, ',');
        getline(ss, email, ',');
        getline(ss, tweets, ',');
        getline(ss, category, '"');

        name = last + "," + first;
        numTweets = std::stoi(tweets);

        add.setUserName(user);
        add.setActualName(name);
        add.setEmail(email);
        add.setNumTweets(numTweets);
        add.setCategory(category);

        map.insert(std::pair<std::string, TwitterData>(user, add));
    }
    dataFile.close();
}

void printData(std::map<std::string, TwitterData> map)
{
    for(auto it = map.cbegin(); it != map.cend(); ++it)
    {
        std::cout << it->first << " " << it->second << std::endl;
    }
}

void deleteByName(std::map<std::string, TwitterData> &map, std::string name)
{
    for(auto it = map.cbegin(); it != map.cend(); ++it)
    {
        if(it->second.getActualName() == name)
        {
            map.erase(it->first);
            return;
        }
    }
}


#endif