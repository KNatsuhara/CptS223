/*
What piece of data read from the file did you use for the key and why?
Data that I used as the key was the username because every username should be unique.

Assuming that the map is using a red-black tree, what is the worst-case Big-O for inserting key-value pairs based on a key?
The worst-case Big-O notation for inserting key-value pairs based on key would be O(logn).

Assuming that the map is using a red-black tree, what is the worst-case Big-O for retrieving data based on a key?
The worst-case Big-O notation for retrieving data based on key would be O(logn).

Assuming that the map is using a red-black tree, what is the worst-case Big-O for deleting key-value pairs based on a key?
The worst-case Big-O notation for deleting data based on key would be O(logn).

Assuming that the map is using a red-black tree, what is the worst-case Big-O for iterating through the entire map?
The worst-case Big-O notation for iterating through the tree based on key would be O(logn).

Based on the specific algorithm that you used to find and remove a key-value pair based on a value, what is the worst-case Big-O?
The worst-case Big-O notation for retrieving data based on key would be O(logn).

Based on your conclusions of the tasks that were performed in this assignment, when and why should we use a map?
Maps should be used whenever you need to store data based on a key. The data is then sorted and inserted by the key value and takes
logarithmic time to search an element in a map by key.

Assuming that the “MostViewedCategory” data in the file represents the kind of Tweets that a particular user views frequently. 
Is a map an ideal data structure to use to retrieve this information, especially if we want to use the info for advertising? If not, what data 
structure would you use instead?

If we are trying to retrieve information from a data structure in the fastest way possible if they're are thousands of different information. I
would stick to a map data structure because it follows a self-balancing binary search tree. Because AVL trees have O(logn) search times, it doesn't
get much better than that, so therefore I would recommend using some sort of BST, AVL Tree or Red-Black Tree (Map) to sort additional information
so that the worst case scenario to retrieve the data will always be O(logn). For advertising purposes, the tree can iterate through all of the data
and look at a particular user to see what their "most view category" is. However, while I do think map would not be a bad data structure to use
to retrieve the data, I could also see the implementation of a linked list or a vector.
*/


#include <map>
#include "TwitterData.hpp"
#include "map.hpp"

int main(int argc, char* argv[])
{
    //1. Syntax map<T1, T2> obj; //Where T1 is key type and T2 is value type
    //2. std::map is associative container that store elements in key value combination
    //   where key should be unique, otherwise it overrides the previous value.
    //3. It is implement using Self-Balance Binary Search Tree (AVL/Red Black Tree)
    //4. It store key value pair in sorted order on the basis of key (assending/decending)
    //5. std::map is generally used in Dictionary type problems

	// we need a map to store our key-value pairs
	// std::map<keyType, ValueType>; What should the key be? What about the value?

    std::map<std::string, TwitterData> map;

    insertData(map);
    std::cout << "---------- Map before deletions----------\n";
    printData(map);

    map.erase("savage1");
    std::cout << "---------- Map after deletion of savage1 ----------\n";
    printData(map);
    deleteByName(map,"Smith,Rick");

    std::cout << "---------- Map after deletion of Smith,Rick ----------\n";
    printData(map);
    
	return 0;
}