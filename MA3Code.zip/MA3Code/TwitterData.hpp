#ifndef TWITTER_DATA_H
#define TWITTER_DATA_H

#include <iostream>
#include <string>
#include <iterator>

class TwitterData
{
public:
	// Are the Big Five necessary?
	// How will this data work with the std::map?

	//Constructor
	TwitterData()
	{
		mpUserName = nullptr;
		mpActualName = nullptr;
		mpEmail = nullptr;
		mpCategory = nullptr;
		mpNumTweets = nullptr;
	}

	//Parameterized Constructor
	TwitterData(const std::string &user, const std::string &name, const std::string &email, 
	const std::string &category, const int &numTweets)
	{
		this->setUserName(user);
		this->setActualName(name);
		this->setEmail(email);
		this->setCategory(category);
		this->setNumTweets(numTweets);
	}

	//Copy Constructor
	TwitterData(const TwitterData& copy)
	{
		//std::cout << "Inside copy constructor!" << std::endl;
		*this = copy;
	}

	//Copy Assignment Operator
	TwitterData& operator=(const TwitterData& copy)
	{
		//std::cout << "Inside copy assignment operator!" << std::endl;
		//check for self-assignment
		if(this != &copy)
		{
			this->mpUserName = copy.mpUserName;
			this->mpActualName = copy.mpActualName;
			this->mpEmail = copy.mpEmail;
			this->mpCategory = copy.mpCategory;
			this->mpNumTweets = copy.mpNumTweets;
		}
		return *this;
	}

	//Move Constructor
	TwitterData(TwitterData&& obj)
	{
		//std::cout << "Inside move constructor!" << std::endl;

		this->mpUserName = obj.mpUserName;
		this->mpActualName = obj.mpActualName;
		this->mpEmail = obj.mpEmail;
		this->mpCategory = obj.mpCategory;
		this->mpNumTweets = obj.mpNumTweets;

		obj.mpUserName = nullptr;
		obj.mpActualName = nullptr;
		obj.mpEmail = nullptr;
		obj.mpCategory = nullptr;
		obj.mpNumTweets = nullptr;
	}

	//Move Assignment Operator
	TwitterData& operator=(TwitterData&& obj)
	{
		//std::cout << "Inside move assignment operator!" << std::endl;
		//check for self-assignment
		if(this != &obj)
		{
			if(this->mpUserName != nullptr)
			{
				this->mpUserName = nullptr;
				this->mpActualName = nullptr;
				this->mpEmail = nullptr;
				this->mpCategory = nullptr;
				this->mpNumTweets = nullptr;
			}
			//Get resources from obj
			this->mpUserName = obj.mpUserName;
			this->mpActualName = obj.mpActualName;
			this->mpEmail = obj.mpEmail;
			this->mpCategory = obj.mpCategory;
			this->mpNumTweets = obj.mpNumTweets;
			//Reset obj
			obj.mpUserName = nullptr;
			obj.mpActualName = nullptr;
			obj.mpEmail = nullptr;
			obj.mpCategory = nullptr;
			obj.mpNumTweets = nullptr;
		}
		return *this;
	}

	//Destructor
	~TwitterData()
	{
		//std::cout << "Inside destructor!" << std::endl;
		this->mpUserName = nullptr;
		this->mpActualName = nullptr;
		this->mpEmail = nullptr;
		this->mpCategory = nullptr;
		this->mpNumTweets = nullptr;
	}

	friend std::ostream& operator << (std::ostream& output, const TwitterData &data)
	{
		output << data.getUserName() << ", " << data.getActualName() << ", " << data.getEmail() << ", " <<
		data.getNumTweets() << ", " << data.getCategory();
		return output;
	}

	std::string getUserName() const; // we do want to return a copy of the string, not the pointer
	std::string getActualName() const; // we do want to return a copy of the string, not the pointer
	std::string getEmail() const;// we do want to return a copy of the string, not the pointer
	std::string getCategory() const; // we do want to return a copy of the string, not the pointer
	int getNumTweets() const; // we do want to return a copy of the integer, not the pointer

	void setUserName(const std::string &newUserName); // you need to implement
	void setActualName(const std::string& newActualName); // you need to implement
	void setEmail(const std::string &newEmail); // you need to implement
	void setCategory(const std::string &newCategory); // you need to implement
	void setNumTweets(const int &newNumTweets); // you need to implement

private:
	std::string *mpUserName, *mpActualName, 
		*mpEmail, *mpCategory;
	int *mpNumTweets;	
};

#endif