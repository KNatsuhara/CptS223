#ifndef __PROBING_HASH_H
#define __PROBING_HASH_H

#include <vector>
#include <stdexcept>
#include <cmath>

#include "Hash.hpp"

using std::vector;
using std::pair;

// Can be used for tracking lazy deletion for each element in your table
enum EntryState {
    EMPTY = 0,
    VALID = 1,
    DELETED = 2
};

template<typename K, typename V>
class ProbingHash : public Hash<K,V> { // derived from Hash
private:
    // Needs a table and a size.
    int num_Elements = 0;
    std::vector<std::pair<std::pair<K, V>, EntryState>> table;
    V dump;
    // Table should be a vector of std::pairs for lazy deletion

public:
    ProbingHash(int n = 11) {
        table.resize(n);
    }

    ~ProbingHash() {
        this->clear();
    }

    bool empty() {
        if(num_Elements == 0)
            return true;
        else
            return false;
    }

    int size() {
        return num_Elements;
    }

    void setSize(int n)
    {
        table.resize(n);
    }

    V& at(const K& key) {
        int bucket_num = hash(key);

        while(table[bucket_num].second != EMPTY && table[bucket_num].first.first != key)
        {
            bucket_num++;
            if(bucket_num = table.size())
                bucket_num = 0;
        }
        
        if(table[bucket_num].first.first == key)
        {
            return table[bucket_num].first.second;
        }

        std::cout << "Key was not found in hash ";
        return dump;
    }

    V& operator[](const K& key) {
        return this->at(key);
    }

    int count(const K& key) {
        return 1;
    }

    void emplace(K key, V value) {
        int bucket_num = hash(key);

        while(table[bucket_num].second != EMPTY && table[bucket_num].first.first != key)
        {
            bucket_num++;
            if(bucket_num = table.size())
                bucket_num = 0;
        }
        
        if(table[bucket_num].first.first == key)
        {
            table[bucket_num].first.second = value;
        }
    }

    void insert(const std::pair<K, V>& pair) {
        if(load_factor() > 0.75)
        {
            rehash();
        }

        int bucket_num = hash(pair.first);
        
        while(table[bucket_num].second == VALID)
        {
            bucket_num++;
            if(bucket_num == table.size())
                bucket_num = 0;
        }
        table[bucket_num].first = pair;
        table[bucket_num].second = VALID;
        num_Elements++;
    }

    void erase(const K& key) {
        int bucket_num = hash(key);

        while(table[bucket_num].second != EMPTY && table[bucket_num].first.first != key)
        {
            bucket_num++;
            if(bucket_num = table.size())
                bucket_num = 0;
        }
        
        if(table[bucket_num].first.first == key)
        {
            table[bucket_num].second = DELETED;
            num_Elements--;
        }
    }

    void clear() {
        table.clear();
        num_Elements = 0;
    }

    int bucket_count() {
        return table.size();
    }

    int bucket_size(int n) {
        if(table[n].second == VALID)
        {
            return 1;
        }
        return 0;
    }

    int bucket(const K& key) {
        return hash(key);
        throw std::out_of_range("Key not in hash");
    }

    float load_factor() {
        return (double)num_Elements / table.size();
    }

    void rehash() {
        rehash(findNextPrime(table.size() * 2));
    }

    void rehash(int n) {
        std::vector<std::pair<std::pair<K, V>, EntryState>> temp = table;
        table.clear();
        num_Elements = 0;
        table.resize(n);

        for(int i = 0; i < temp.size(); i++)
        {
            if(temp[i].second == VALID)
                insert(temp[i].first);
        }
    }

private:
    int findNextPrime(int n)
    {
        while (!isPrime(n))
        {
            n++;
        }
        return n;
    }

    int isPrime(int n)
    {
        for (int i = 2; i <= sqrt(n); i++)
        {
            if (n % i == 0)
            {
                return false;
            }
        }

        return true;
    }

    int hash(const K& key) {
        return key % table.size();       
    }
};

#endif //__PROBING_HASH_H
