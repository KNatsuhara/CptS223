#include "ChainingHash.hpp"
#include "ProbingHash.hpp"
#include "ParallelProbingHash.hpp"

/*

1. How did the serial implementations for the ChainingHash and ProbingHash compare to each other? Did you expect the time results obtained? Explain.
The serial implementations for inserting all the values into the ChainingHash (~1.8s) was slower than the ProbingHash (~0.33). The reason why inserting
into the ChainingHash is slower than inserting into the ProbingHash is because when inserting a new value into the ProbingHash you only need to change the value
of the index of the vector, versus the chainingHash which requires the creation of a new node inserted at the front/back of a linked list. The rest of the functions,
erase and search all run at constant time and have the same completion time.

2. Compare the parallel and serial implementations for the ProbingHash. Did the parallel implementation provide you with the expected speedup? Explain.
The parallel implementation did not provide us with the expected speedup? Although multiple threads are working to insert each of the values into the hash table, I
believe the time issue comes when rehashing the table. Since we couldn't use multiple threads to rehash the table when the loading factor exceeded 0.5, I believe the 
time did not speed up.

3. What could you change in your parallel implementations to improve performance and speedup? Explain.
I don't know how I can implement mutliple threads to work on the rehash function, but I believe that could speed up the process in inserting all the values
into the hash table.

*/

int main()
{
    std::fstream results("HashAnalysis.txt");

    // clocks
    clock_t chain_start, chain_end;


    ChainingHash<int, int> chain_hash;

    // set size to 101
    chain_hash.setSize(101);

    // insert key/values from 1-1,000,000
    chain_start = clock();
    for (int i = 1; i <= 1000000; i++)
    {
        std::pair<int, int> insert(i, i);
        chain_hash.insert(insert);
    }
    chain_end = clock();

    // report time it took to insert
    results << "Chain Insertion: " << ((double)(chain_end - chain_start)/CLOCKS_PER_SEC) << std::endl;

    // search for value 177
    chain_start = clock();
    std::cout << chain_hash.at(177) << std::endl;
    chain_end = clock();

    // report time 
    results << "Chain Search for 177: " << ((double)(chain_end - chain_start)/CLOCKS_PER_SEC) << std::endl;

    // search for value 2,000,000
    chain_start = clock();
    std::cout << chain_hash.at(2000000) << std::endl;
    chain_end = clock();

    // report time
    results << "Chain Search for 2000000: " << ((double)(chain_end - chain_start)/CLOCKS_PER_SEC) << std::endl;

    // remove value 177
    chain_start = clock();
    chain_hash.erase(177);
    chain_end = clock();

    // report time
    results << "Chain Erase 177: " << ((double)(chain_end - chain_start)/CLOCKS_PER_SEC) << std::endl;

    // report final size, bucket count, load factor
    results << "Load Factor: " << chain_hash.load_factor() << std::endl;
    results << "Bucket Count: " << chain_hash.bucket_count() << std::endl;
    results << "Size of Vector: " << chain_hash.size() << std::endl;

    ProbingHash<int, int> probe_hash;

    // clocks
    clock_t probe_start, probe_end;

    // set size to 101
    probe_hash.setSize(101);

    // insert key/values from 1-1,000,000
    probe_start = clock();
    for (int i = 1; i <= 1000000; i++)
    {
        std::pair<int, int> insert(i, i);
        probe_hash.insert(insert);
    }
    probe_end = clock();

    // report time it took to insert
    results << "Probe Insertion: " << ((double)(probe_end - probe_start)/CLOCKS_PER_SEC) << std::endl;

    // search for value 177
    probe_start = clock();
    std::cout << probe_hash.at(177) << std::endl;
    probe_end = clock();

    probe_hash.emplace(5, 100);

    // report time 
    results << "Probe Search for 177: " << ((double)(probe_end - probe_start)/CLOCKS_PER_SEC) << std::endl;

    // search for value 2,000,000
    probe_start = clock();
    std::cout << probe_hash.at(2000000) << std::endl;
    probe_end = clock();

    // report time
    results << "Probe Search for 2000000: " << ((double)(probe_end - probe_start)/CLOCKS_PER_SEC) << std::endl;

    // remove value 177
    probe_start = clock();
    probe_hash.erase(177);
    probe_end = clock();

    // report time
    results << "Probe Erase 177: " << ((double)(probe_end - probe_start)/CLOCKS_PER_SEC) << std::endl;

    // report final size, bucket count, load factor
    results << "Load Factor: " << probe_hash.load_factor() << std::endl;
    results << "Bucket Count: " << probe_hash.bucket_count() << std::endl;
    results << "Size of Vector: " << probe_hash.size() << std::endl;

    //-------------------------------------Parallel Programming--------------------------------------

    omp_set_num_threads(omp_get_max_threads());

    ParallelProbingHash<int, int> parallel_hash;

    parallel_hash.setSize(101);

    clock_t parallel_start, parallel_end;

    // insert
    parallel_start = clock();
    #pragma omp parallel for schedule(dynamic, 2) shared(parallel_hash)
        for (int i = 1; i <= 1000000; i++)
        {
            //std::cout << "From thread: " << omp_get_thread_num() << " - load: " << parallel_hash.load_factor() << std::endl;
            std::pair<int,int> insert(i,i);
            parallel_hash.insert(insert);
        }

    parallel_end = clock();

    results << "Parallel Insertion: " << ((double)(parallel_end - parallel_start)/CLOCKS_PER_SEC) << std::endl;

    // search for 177
    parallel_start = clock();
    parallel_hash.at(177);
    parallel_end = clock();
    results << "Parallel Search for 177: " << ((double)(parallel_end - parallel_start)/CLOCKS_PER_SEC) << std::endl;

    // search for 2,000,000
    parallel_start = clock();
    parallel_hash.at(2000000);
    parallel_end = clock();
    results << "Parallel Search for 2,000,000: " << ((double)(parallel_end - parallel_start)/CLOCKS_PER_SEC) << std::endl;

    // remove 177
    parallel_start = clock();
    parallel_hash.erase(177);
    parallel_end = clock();
    results << "Parallel Erase 177: " << ((double)(parallel_end - parallel_start)/CLOCKS_PER_SEC) << std::endl;

    std::cout << std::endl;

    results.close();

    return 0;
}