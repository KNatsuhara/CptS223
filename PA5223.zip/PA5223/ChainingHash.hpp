/*
 *  Separate chaining hashtable
 */

#ifndef __CHAINING_HASH_H
#define __CHAINING_HASH_H

// Standard library includes
#include <iostream>
#include <vector>
#include <list>
#include <stdexcept>
#include <cmath>
#include <iterator>
#include <ctime>
#include <fstream>

// Custom project includes
#include "Hash.hpp"

// Namespaces to include
using std::vector;
using std::list;
using std::pair;

using std::cout;
using std::endl;

//
// Separate chaining based hash table - derived from Hash
//
template<typename K, typename V>
class ChainingHash : public Hash<K,V> {
private:
    std::vector<std::list<std::pair<K,V>>> table;
    int num_Elements = 0;
    V dump;

public:
    ChainingHash(int n = 11)
    {
        table.resize(n);
    }

    ~ChainingHash() {
        this->clear();
    }

    bool empty() 
    {
        if(num_Elements == 0)
            return true;
        else
            return false;
    }

    int size() 
    {
        return num_Elements;
    }

    void setSize(int n)
    {
        table.resize(n);
    }

    V& at(const K& key) {

        // insesrt key into hash to get bucket number
        int bucket_num = hash(key);
        for (typename std::list<std::pair<K,V>>::iterator it = table.at(bucket_num).begin(); it != table.at(bucket_num).end(); it++)
        {
            if (key == (*it).first)
                return (*it).second;
        }
        std::cout << "Key was not found in hash ";
        return dump;
    }

    V& operator[](const K& key) 
    {
        return this->at(key);
    }

    int count(const K& key) {
        return 1;
    }

    void emplace(K key, V value) {
        int bucket_num = hash(key);

        // iterate through bucket number till key == iterator.key
        for (typename std::list<std::pair<K,V>>::iterator it = table.at(bucket_num).begin(); it != table.at(bucket_num).end(); it++)
        {
            if (key == (*it).first)
                (*it).second = value;
        }
    }

    void insert(const std::pair<K, V>& pair) 
    {
        if(load_factor() > 0.75)
        {
            // std::cout << "Rehashing.....\n";
            // std::cout << rehashCount++ << std::endl;
            // std::cout << "Size of table: " << table.size() << std::endl;
            table.at(hash(pair.first)).push_back(pair);
            num_Elements++;
            rehash();
        }
        else
        {
           table.at(hash(pair.first)).push_back(pair);
           num_Elements++;
        }
    }

    void erase(const K& key) {
        int bucket_num = hash(key);

        // iterate through bucket number till key == iterator.key
        typename std::list<std::pair<K,V>>::iterator it = table.at(bucket_num).begin();
        for (; it != table.at(bucket_num).end(); it++)
        {
            if (key == (*it).first)
            {
                table.at(bucket_num).erase(it);
                num_Elements--;
                break;
            }
        }
    }

    void clear() {
        for(int i = 0; i < table.size(); i++)
        {
            table.at(i).clear();
        }
        table.clear();
        num_Elements = 0;
    }

    int bucket_count() {
        return table.size();
    }

    int bucket_size(int n) {
        return table[n].size();
    }

    int bucket(const K& key) {
        return hash(key);
        throw std::out_of_range("Key not in hash");
    }

    float load_factor() {
        return (double)num_Elements / table.size();
    }

    void rehash() {
        rehash(findNextPrime(table.size() * 2));
    }

    void rehash(int n) {
        std::vector<std::list<std::pair<K,V>>> temp = table;
        table.clear();
        num_Elements = 0;
        table.resize(n);
        
        for(int i = 0; i < temp.size(); i++)
        {
            for (typename std::list<std::pair<K,V>>::iterator it = temp.at(i).begin(); it != temp.at(i).end(); it++)
            {
                table.at(hash((*it).first)).push_back((*it));
                num_Elements++;
            }
        }
    }


private:
    int findNextPrime(int n)
    {
        while (!isPrime(n))
        {
            n++;
        }
        return n;
    }

    int isPrime(int n)
    {
        for (int i = 2; i <= sqrt(n); i++)
        {
            if (n % i == 0)
            {
                return false;
            }
        }

        return true;
    }

    int hash(const K& key) {
        return key % table.size();       
    }

};

#endif //__CHAINING_HASH_H
